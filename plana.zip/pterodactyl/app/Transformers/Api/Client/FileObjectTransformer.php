<?php

namespace Pterodactyl\Transformers\Api\Client;

use League\Fractal\TransformerAbstract;


class FileObjectTransformer extends TransformerAbstract
{
    /**
     * @param array $fileData
     * @return array
     */
    public function transform(array $fileData): array
    {
        return [
            'key' => base64_encode($fileData['path']), 
            'name' => $fileData['name'],
            'path' => $fileData['path'],
            'is_file' => (bool) $fileData['is_file'],
            'size' => (int) $fileData['size'],
            'mimetype' => $fileData['mimetype'],
            'mode' => (string) $fileData['mode'],
            'created_at' => $fileData['created_at'],
            'modified_at' => $fileData['modified_at'],
        ];
    }
}