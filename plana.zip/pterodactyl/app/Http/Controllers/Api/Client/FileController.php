<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;
use Pterodactyl\Models\Server;
use Pterodactyl\Transformers\Api\Client\FileObjectTransformer; 
use Symfony\Component\Finder\Finder; 

class FileController extends ClientApiController
{

    public function search(ClientApiRequest $request, Server $server)
    {
        $this->authorizeContext(__METHOD__); 

        $directory = rtrim($request->query('directory', ''), '/');
        $searchTerm = $request->query('query');

        if (empty($searchTerm) || strlen($searchTerm) < 2) {
            return $this->fractal->collection([])
                        ->transformWith(FileObjectTransformer::class)
                        ->toArray();
        }

        $serverPath = $server->getAbsoluteFileLocation(); 

        $fullPath = $serverPath . '/' . $directory;
        $fullPath = rtrim($fullPath, '/'); 

        if (!is_dir($fullPath) || !str_starts_with($fullPath, $serverPath)) {
            return $this->fractal->collection([])
                        ->transformWith(FileObjectTransformer::class)
                        ->toArray();
        }

        $finder = new Finder();
        try {
            $finder->in($fullPath)
                   ->name('*' . $searchTerm . '*') 
                   ->depth('< 5') 
                   ->ignoreDotFiles(false) 
                   ->ignoreUnreadableDirs(true) 
                   ->filter(function (\SplFileInfo $file) use ($serverPath) {

                       return str_starts_with($file->getPathname(), $serverPath);
                   })
                   ->sortByName(); 

            $results = [];
            foreach ($finder as $file) {

                $results[] = [
                    'name' => $file->getFilename(),
                    'path' => str_replace($serverPath, '', $file->getPathname()), 
                    'is_file' => $file->isFile(),
                    'size' => $file->getSize(),
                    'mimetype' => mime_content_type($file->getPathname()),
                    'mode' => sprintf('%o', $file->getPerms() & 0777),
                    'created_at' => date('Y-m-d H:i:s', $file->getATime()), 
                    'modified_at' => date('Y-m-d H:i:s', $file->getMTime()),

                ];
            }

            
            return $this->fractal->collection($results)
                        ->transformWith(FileObjectTransformer::class)
                        ->toArray();

        } catch (\Exception $e) {
            \Log::error('File search error: ' . $e->getMessage(), ['server_id' => $server->id, 'path' => $fullPath]);
            return $this->fractal->collection([])
                        ->transformWith(FileObjectTransformer::class)
                        ->toArray();
        }
    }
}