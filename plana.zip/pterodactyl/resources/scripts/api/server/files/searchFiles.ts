import http, { PaginatedResult } from '@/api/http';
import { FileObject } from './loadDirectory'; 

export const searchServerFiles = async (serverId: string, directory: string, query: string): Promise<FileObject[]> => {

    const encodedDirectory = directory === '/' ? '' : encodeURIComponent(directory);

    const url = `/api/client/servers/${serverId}/files/search?directory=${encodedDirectory}&query=${encodeURIComponent(query)}`;

    const { data } = await http.get(url);
    return data.data.map((item: any) => ({
        key: item.attributes.key || item.attributes.path, 
        name: item.attributes.name,
        path: item.attributes.path,
        isFile: item.attributes.is_file,
        size: item.attributes.size,
        mimetype: item.attributes.mimetype,
        mode: item.attributes.mode,
        createdAt: new Date(item.attributes.created_at),
        modifiedAt: new Date(item.attributes.modified_at),
    })) as FileObject[]; 